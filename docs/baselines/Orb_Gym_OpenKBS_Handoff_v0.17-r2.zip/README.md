# Orb Gym — OpenKBS Product and Delivery Brief

Source baseline: product architecture v0.17. Reviewed handoff revision: v0.17-r2, 6 November 2026. Supersedes the earlier ZIP for builder handoff.
Purpose: store the complete product brief, prepare a detailed project-specific implementation plan and populate the OpenKBS delivery board. This package does not authorise app building or deployment.

## What to do

1. Upload this ZIP to the correct Orb Gym OpenKBS project.
2. Send the complete text of prompts/01-store-and-audit.md.
3. After the storage/audit response, send prompts/02-plan-and-create-delivery-cards.md.
4. Review the resulting plan, coverage report, unresolved choices and board cards before authorising implementation.

The reference screenshots showing Opulence/Orb Security identify builder features only. They are not a destination or a starter product to overwrite.

## Read order

Read docs/review-report.md first, then docs/builder-operating-rules.md, docs/decisions-and-open-items.md, docs/product-architecture.md, every docs/modules file, docs/source-requirement-register.md, docs/delivery-priorities.md, docs/board-card-contract.md and docs/acceptance-scenarios.md. Do not use a summary as a replacement for the detailed source.

## Authority and provenance

Source: live architecture at https://chatgpt.com/space/page_10d1219029108191bd0f765b682d2d93 .
The original architecture and source register are preserved in history/. Active working copies correct known stale wording as recorded in docs/review-report.md; this review does not edit the live Page. The external logo reference is made portable by pointing to the supplied image bundled here. Section extracts repeat source content intentionally for focused work. Source IDs refer to whole blocks and require decomposition into atomic implementation requirements.

Current founder decisions supersede historical alternatives. docs/decisions-and-open-items.md identifies known supersessions. Builder findings may recommend changes but cannot silently redefine the product. This pack is a planning baseline, not a claim that all provider, legal, commercial and operational choices are resolved.

## Assets

assets/orb-gym-logo.png is the supplied Orb Gym logo, copied unchanged. Its dark wordmark needs a contrasting surface; do not assume this single asset supplies a dark-mode white wordmark or a standalone icon. Prepare suitable approved variants before production. Use the brand icon from the supplied mark; do not substitute a generated logo. The five UI directions are governed by the detailed rules in module 08 and docs/design-and-token-deliverables.md; prior concept images are illustrative and are not bundled production assets.

## Outputs OpenKBS must prepare

Detailed implementation plan, atomic requirement coverage matrix, delivery card index, decision/gap log, bounded specifications and verification plan. Save those under docs/delivery/ and spec/ as described in their README files. Board cards link back to these files and source requirements.

manifest.json records file checksums and source baseline. verify-package.py verifies the transferred files. A successful checksum proves transfer integrity, not product completeness or implementation quality.

## Platform references

OpenKBS official documentation: https://openkbs.com/docs/cli
Orb Solutions visual reference: https://orbsolutions.co.uk

The builder must inspect its actual project and current platform capabilities before choosing implementation details. No provider credentials, production customer records or payment secrets are included.


## Reviewed additions and remaining decisions

Read docs/modules/11-finance-reports-and-analytics.md, docs/modules/12-access-navigation-and-notifications.md, docs/planning-gap-register.md, docs/design-and-token-deliverables.md and docs/platform-evidence-and-delivery-gates.md. OpenKBS must cover OG-REV IDs as well as all original OG-SRC IDs and prepare the additional matrices/catalogue required in prompt 02. This is a detailed planning brief with explicit remaining choices, not an approved final technical/UI specification. History is provenance only and prompt 02 is not executed merely by reading it.

## Mandatory delivery sequence — revision r2

Every delivery card must be numbered 00, 01, 02 and onwards, with prerequisite work first. This applies to the complete plan, parent/child cards, titles, coverage and ordered card index. OpenKBS prepares the detailed dependency graph and sequence before card creation. OG-REV-011 is the governing rule. This revision supersedes the reviewed r1 ZIP; product source remains baseline 0.17.
