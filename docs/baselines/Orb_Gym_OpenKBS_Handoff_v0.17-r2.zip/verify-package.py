#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
errors=[]
for item in manifest['files']:
    path=root/item['path']
    if not path.is_file():
        errors.append('Missing: '+item['path']); continue
    data=path.read_bytes()
    if len(data)!=item['size_bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
        errors.append('Mismatch: '+item['path'])
for error in errors: print(error)
print(str(len(manifest['files']))+' files checked; '+str(len(errors))+' errors')
sys.exit(bool(errors))
