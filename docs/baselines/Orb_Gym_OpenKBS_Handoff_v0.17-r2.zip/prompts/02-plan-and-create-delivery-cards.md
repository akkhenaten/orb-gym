# Prompt 2 — Prepare implementation plan and delivery board

Use the complete Orb Gym baseline stored at docs/orb-gym-baseline-v0.17-r2/ and its handoff index. Read all active baseline files before planning, including review-report.md and review additions. History is provenance only. Our delivery priorities and architecture are constraints; you must prepare the detailed technical implementation plan from your knowledge of this actual project and current OpenKBS capabilities.

You are authorised to inspect the project, author specifications/plans and create delivery backlog cards. You are not yet authorised to implement application code or deploy. Avoid any automatic Spec/Plan approval action that triggers building. Report if the platform cannot separate these stages.

## Inspect first
Inspect actual files, configuration, runtime, existing data schema, auth, integrations, tests and deployment setup without exposing secrets. Inspect the board's real columns, card types and existing cards using supported OpenKBS capabilities/current docs. Reuse matching cards and create explicit dependency links without duplicates. Do not invent CLI commands or card IDs.

## Decompose and plan
Apply docs/delivery-priorities.md and docs/board-card-contract.md within the baseline. Create a dependency-led implementation plan covering all OG-SRC and OG-REV source requirements, all four journeys, platform admin, coach/PT subjourneys and all five design presets. Stage delivery without silently dropping later scope.

For every planned capability specify current state, target behaviour, affected modules, data entities/relations, scope enforcement, state transitions, cross-module events, provider boundaries, migrations, audit, failure/retry/reversal, verification and acceptance evidence. Separate ordinary configurable business policies from decisions that genuinely block safe implementation.

Use actual platform findings to recommend architecture and integrations. Explain unsupported capabilities and alternatives. Flag unresolved choices with a recommendation, consequence and exact blocking cards. Do not guess credentials, payment terms, coach rates, retention periods or real business data.

## Save outputs
Write these implementation artifacts at project root, outside the immutable baseline:
- docs/delivery/implementation-plan.md — dependencies, phases, complete scope, technical decisions, integration and verification strategy, assumptions, blockers and release criteria.
- docs/delivery/requirements-coverage.csv — atomic requirement ID, source block ID, source path/section, source status, requirement, journey, module, phase, delivery sequence number, card ID, specification path, acceptance IDs, status and decision ID. Quote/escape CSV fields correctly. Every source block needs a disposition including open decision, context or superseded wording; do not pretend each block is one requirement.
- docs/delivery/decision-log.md — settled directions, actual findings, recommendations and unresolved choices.
- docs/delivery/card-index.md — delivery sequence numbers, real card IDs, card kinds, titles, priorities, parent/child/dependency links, specification paths and state.
- docs/delivery/platform-capability-matrix.md — actual project findings and provider/device feasibility, evidence, limits, dependencies and costs.
- docs/delivery/access-matrix.md — role/action/record/field permissions, multi-role rules and negative checks.
- docs/delivery/screen-and-notification-matrix.md — all role/device routes/states and event/recipient/channel/deep-link rules.
- docs/delivery/design-token-map.md — complete preset/component/mode token definitions and resolved or explicitly pending values/assets.
- docs/delivery/report-catalogue.md — metric definitions, sources, scope, time basis, freshness and missing-data rules.
- docs/delivery/verification-plan.md — end-to-end acceptance, permission negatives, retry/concurrency, responsive UI, accessibility and recovery checks.
- spec/orb-gym/<bounded-feature>.md — detailed specifications linked by cards.

## Create board cards
Follow OG-REV-011 in docs/board-card-contract.md: every delivery parent/child card must have a unique numbered title, starting 00, 01, 02, in dependency-led logical order. Prepare the complete ordered queue before creating cards; preserve actual board IDs.
Create delivery parent cards and bounded, actionable child cards for the complete scope. Each card must follow the baseline card contract: goal, source IDs/file paths, scope/exclusions, project findings, spec/plan links, affected data/access, dependencies, migration/recovery requirements, acceptance criteria and required evidence. Link dependencies through actual board relationships when supported; otherwise record explicit IDs and blockers in card content.

Use an existing backlog-equivalent column for newly created delivery cards; nothing becomes In Progress or Done merely because it was planned. Preserve existing card states and record existing verified capability/delta work. Do not flatten the entire product into a handful of vague module cards or create redundant cards for the duplicated module extracts. Do not choose an arbitrary card count.

## Reconcile before reporting
Check every atomic requirement has a card or a reasoned disposition. Check every card has source scope, verification and correct dependency order; verify coverage of owner/staff/member/vendor, platform admin, tenancy, navigation, tokens/white label, documents/public pages, coaches/classes/PT, membership/payments, HR/rota, attendance, POS/stock, task hierarchy/facilities/contractors, feed/cases, analytics/calendar and AI.

Finish with actual saved paths, board/card counts, coverage results, unresolved decisions and recommended first delivery batch. State clearly that no application build/deployment has been performed. Pause for plan review before implementation.


Review r1 requirements: address GAP01–GAP16 with recommendations and affected card IDs. Distinguish a first-release proposal from the complete agreed scope. Include all OG-REV items in requirements-coverage.csv. Record each source block's disposition separately so contextual or superseded content is not dropped invisibly. Do not claim every Facebook feature, payroll filing, full accounting or offline till operation is included merely because the founder used a broad category name. Map stated features completely and propose unresolved options explicitly.

Revision r2 founder requirement: number every Orb Gym delivery card in a single global sequence from 00, following prerequisite order. Include sequence numbers in the implementation plan, requirement mappings, specifications and card index, alongside stable OpenKBS IDs. Verify contiguous unique numbering for the initial plan, topological dependency order and actual board display order (or document the ordered-index fallback). Numbered titles are mandatory. Parent rollups are not implementation blockers for their own children. Do not restart numbering by module. Preserve existing work and record any later re-numbering of unstarted cards with aliases and updated references.
