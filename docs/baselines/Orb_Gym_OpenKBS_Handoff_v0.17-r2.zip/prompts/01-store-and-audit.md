# Prompt 1 — Store and audit the supplied product pack

This is the Orb Gym product documentation handoff. Store the attached Orb_Gym_OpenKBS_Handoff_v0.17-r2.zip in this project's files and extract its contents into a dedicated folder:

docs/orb-gym-baseline-v0.17-r2/

Preserve its complete internal folder structure. Do not paste only a summary into chat, discard detailed modules, or replace existing product files blindly. Inspect the project identity first. The reference screenshots of Opulence/Orb Security are not the Orb Gym project; if this is the wrong project, stop and report that mismatch without changing it.

Read README.md and docs/builder-operating-rules.md within the extracted folder. Verify the manifest checksums using verify-package.py if the runtime permits; otherwise verify each listed file with equivalent hashing. Report exact missing/mismatched files. Preserve the supplied logo bytes.

Then read every active included Markdown file (history files are provenance only; reading prompt 02 does not authorise executing it), including all detailed module files, architecture, source register, decisions, priorities, board-card contract and acceptance scenarios. Recognise superseded directions as explained in decisions-and-open-items.md.

Create a short project entry document at docs/orb-gym-handoff-index.md that links the stored baseline, records version/source date and states the read order. If this path exists, update it carefully with version history rather than erasing unrelated material.

Respond with the actual stored path, complete file inventory, verification outcome, source version, existing project identity and any ingestion blockers or conflicting existing instructions. Do not claim files were stored if you cannot actually write them.

This stage is documentation ingestion and read-only project inspection. Do not create application code, execute builds/deployments, change live integrations or create delivery cards yet. Wait for the separate planning prompt.


This is reviewed package v0.17-r2. Read docs/review-report.md first for precedence, corrected errors and limitations. Use the reviewed active files, not the historical originals. Do not update a previously stored v0.17 folder in place; retain both and point the handoff index to v0.17-r2 as current. Report whether the exact platform project can support the separate ingestion/planning stages.
