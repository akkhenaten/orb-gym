# Specification Output Contract

OpenKBS will author bounded feature specifications at project-root spec/orb-gym/ during the planning stage. This pack does not contain a fabricated implementation plan.

Each specification must include source IDs; concrete journey and before/after behaviour; entities and relationships; tenant/gym/RBAC rules; state transitions; event/API/worker boundaries based on actual project findings; UI across desktop/tablet/mobile; token/theme rules; failure/retry/reversal; migration and rollback considerations; external dependencies; measurable acceptance and negative cases; unresolved decisions; board card links.

Specifications cover implementation detail without changing product intent. Changes to scope require a traceable decision and updated source baseline. Planning a specification is not permission to build it.


Revision r2: OG-REV-011 requires a single dependency-ordered sequence of delivery cards from 00, 01, 02 onward. Follow docs/board-card-contract.md for title format, parent/child handling, stable platform IDs, ordering checks and subsequent changes. Include sequence numbers alongside board IDs in all delivery mappings.
