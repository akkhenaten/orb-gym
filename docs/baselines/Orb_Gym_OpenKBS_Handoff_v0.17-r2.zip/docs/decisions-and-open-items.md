# Decisions and Open Items

Baseline 0.17 · 6 November 2026

## Settled directions

- Product is Orb Gym: multi-company workspace platform; owner creates multiple gyms; separate platform administration.
- Four customer journeys: owner/admin/management; scoped staff; member including PT-only limited access; vendor/contractor. Rental coaches have a limited role with authorised class tools.
- Default UI is Orb Gym Basic 01 using Orb Solutions design; all five complete presets are tokenised and support light/dark.
- Desktop left navigation; iPad/tablet and mobile bottom navigation, including tablet landscape. Content pane count adapts independently.
- Company Settings owns brand/style/company details; Gym Settings provides permitted local overrides and public content. Documents composes templates and consumes published brand configuration.
- Orb Gym default remains until explicit white-label publication. Every page displays “Orb Gym - powered by orbsolutions.co.uk”.
- AI assistant name is Orb. Icon is Orb Gym by default and approved company mark when white labelled. AI tools follow trusted commands/RBAC.
- Cleaning/maintenance/admin share one engine, with grouped tasks, parent/children, dependencies, typed feed, evidence, approvals and audit trail.
- Hourly employed-coach PT and PT-only onboarding/access are included. Prepaid PT packages/session bundles remain excluded. Historic blanket PT exclusions do not exclude the later confirmed hourly PT journeys.
- Rental-coach commercial terms differ from employed-coach wages/hourly customer prices/internal allocations; do not collapse those into one rate.
- Screenshots are reference only. Primal and Valkyrie are demonstration gyms, not seeded production customer records.

## Open choices to investigate

Identity provider; exact OpenKBS hosting/runtime configuration; payment/DD and terminal integration; printer support; maps/place search; email/domain setup; accounting and payroll interfaces; storage privacy and retention; real commercial terms; booking hold duration and cancellation/no-show policies; who approves sensitive actions; age/guardian scope; workload and restore targets.

Prepare a recommendation with alternatives and consequences for each material choice. Use reversible configuration for ordinary business settings; never hard-code guessed rates or thresholds.

## Source authority

Current founder decisions override superseded conversation wording. Detailed extracted module files and architecture export describe the same baseline. Requirement register supplies source references. Builder-authored specs/plans cannot silently change product scope. Raise a conflict with exact file/section/source IDs and a recommended resolution.

The original source architecture is included in full; generated-image figures/logos/sample dates are not approved data. The active product implementation will use approved logo bytes. No file in this pack is authority to use real customer/health/payment data during development.


## Review r1 clarification

OpenKBS is the selected builder; actual runtime/integration choices are still open. Use the exact mandatory footer rather than older generic attribution wording. Hourly employed-coach PT is included; prepaid PT packages/session bundles are excluded. Soft Glass 04 and the old iOS-inspired Soft summary are one preset. See planning-gap-register.md for the full owned decision list and review-report.md for corrections.

All agreed product scope must be mapped. The first-release boundary is not yet approved: phasing must not silently remove features or invent a simultaneous launch commitment. This handoff revision corrects working documents; it does not claim the live Page or any app was updated.

## Confirmed founder decision — handoff r2

Every delivery card is numbered in a single logical sequence: 00, 01, 02 and onwards. Prerequisites precede dependent work. This applies to parent and child cards and all delivery references; stable OpenKBS IDs remain separate. See OG-REV-011. This is settled, not an open design choice.
