# Cross Module Acceptance Scenarios

All are planned verification requirements, not executed tests. Use synthetic data and capture expected/actual outcome, environment/build, role, source requirement IDs and evidence.

| ID | Scenario and expected outcome |
|---|---|
| AC01 | Two companies each have multiple gyms; API, search, files, calendar, AI and exports cannot cross their boundary. |
| AC02 | Owner signup retry resumes one workspace; invited staff/member does not accidentally create an owner workspace. |
| AC03 | Manager/supervisor invites staff only within delegated gym/role scope; privilege escalation denied. |
| AC04 | Avatar/name/notifications/theme preference update without altering roles or signed records. |
| AC05 | Company brand publishes across app/pages/Orb/new documents; draft uploads do not activate white labelling. |
| AC06 | Gym override inherits/reset correctly; disable white labelling restores defaults; exact footer stays visible. |
| AC07 | All five presets work across roles and modes; desktop left/iPad-mobile bottom navigation preserves context. |
| AC08 | Self signup, invitation and temporary credential routes complete verification, forms and holding-state onboarding. |
| AC09 | PAR-Q review, payment-method/DD setup, collection and membership approval remain distinct; premature activation denied. |
| AC10 | Member entitlement single/all gyms and PT-only status enforce correct booking, feed and entry access. |
| AC11 | Coach invite is not an entry pass; approved individual PT pass is gym/time-bound and duplicate scans are safe. |
| AC12 | PT-only upgrade reuses identity, valid forms and history while new member access waits for activation. |
| AC13 | Rental coach sees only own permitted class/resource/client-access scope; no member-directory/HR leak. |
| AC14 | Employed coach hourly override/default snapshots correctly; wages/internal revenue allocation are separate. |
| AC15 | Final-place concurrent class booking cannot oversell; pending tender/expired hold/late confirmation reconcile. |
| AC16 | One-off and regular classes show dates/capacity exceptions and accepted cancellation/no-show policy version. |
| AC17 | Coach/class/PT/room/rota reservations detect cross-gym overlaps, maintenance and travel conflicts. |
| AC18 | Coach register finalisation/correction updates member history; gym entry is not automatic class attendance. |
| AC19 | Current duty view distinguishes scheduled and confirmed staff; leaver disappears from current directory. |
| AC20 | Staff HR, payslips, disciplinary and one-to-one records have field/participant restrictions and retained history. |
| AC21 | Shared task templates create recurring occurrences and children; grouping preserves original IDs/evidence. |
| AC22 | Parent closure respects required unfinished children; dependency cycles rejected; group costs not duplicated. |
| AC23 | Card feed/attachments/decisions/audit tabs show the same typed records; private notes never reach member/vendor. |
| AC24 | Asset QR reports/links faults; contractor quote revision/approval and completion verification preserve versions. |
| AC25 | Invoice/commitment/payment totals reconcile; repair closure and asset return-to-service remain distinct. |
| AC26 | Barcode receiving, sale, stocktake, transfer, return and adjustment preserve per-gym stock ledger. |
| AC27 | Till retries cannot double charge/deduct; quick sale has no stocked item; refund/stock return separate. |
| AC28 | Branded receipt prints/appears in member app; repeated delivery does not duplicate sale or rewrite issued data. |
| AC29 | Public gym/coach page auto-update uses approved records; private documents and unapproved prices never publish. |
| AC30 | Flip cards usable by keyboard/touch/reduced motion; all public booking links preserve gym/offer context. |
| AC31 | Feed mentions/location/moderation obey audience; post-to-case conversion retains original visibility. |
| AC32 | Attendance corrections/freeze/data gaps affect retention interpretation; outreach/offer uses authorised action. |
| AC33 | Calendar events deep-link correctly for every role; private HR titles are concealed; stale/revoked links fail safely. |
| AC34 | Orb sources reports and executes authorised routine commands; approvals and retry protection remain enforced. |
| AC35 | Upload failure, session expiry, resize and rotation do not create false saved states or lose recoverable draft context. |
| AC36 | Database/evidence restore reconciles financial records, issued files and pending jobs; recovery evidence recorded. |

Each feature spec adds detailed local checks and maps these cross-module cases. Agree measurable accessibility, performance, capacity and recovery targets rather than claiming generic production readiness.


## Review r1 additional scenarios

These are required planning checks, not tests already run. Select exact policy values through the gap register before writing outcome assertions that depend on them.

| ID | Scenario and expected outcome |
|---|---|
| AC37 | Owner transfer preserves an owner; workspace suspension/restoration respects scoped access; support access is bounded and audited. |
| AC38 | Member recovery/invite tokens expire/revoke correctly; verified existing account links without duplicate profile; revoked sessions cannot complete old grants. |
| AC39 | Membership freeze/cancel/reactivate produces explicit effective billing, booking and entry changes without erasing receipts/history. |
| AC40 | Course/block and waiting-list acceptance respect chosen partial/expiry rules and concurrent places; RSVP never consumes capacity unexpectedly. |
| AC41 | Rental-coach rent/arrears and employed-coach earnings/adjustments reconcile to separate source charges; arrangement change resolves future bookings and access. |
| AC42 | Leave/swap/cover approval, cross-gym travel, published shift changes and timesheet correction maintain rota history and the truthful duty view. |
| AC43 | Training/SOP revisions, expiry, signed contracts and restricted payslip delivery preserve access and version evidence; staff archive/reactivation reviews permissions. |
| AC44 | Supplier accept/decline, operative delegation/revocation, quote variation and partial invoice/payment remain distinct; contractor cannot self-approve. |
| AC45 | Company/gym finance aggregates reconcile to charges, collections, credits, internal allocations and costs once; incomplete profit is labelled unavailable/incomplete. |
| AC46 | Report/AI/export metric definitions agree across periods/gyms; private fields remain restricted during asynchronous generation and after role revocation. |
| AC47 | Till cash shift reconciliation, pending/failed tender, authorised void/discount, unknown barcode and insufficient stock follow explicit policy; no phantom completed sale. |
| AC48 | Required notifications target authorised recipients once, honour channel preferences, distinguish acknowledgement and recover from failed sending; sensitive data is absent from message previews. |
| AC49 | Template required fields, preview/review/publication and signature/issued snapshot work; template editing alone cannot issue financial records or assert legal approval. |
| AC50 | Landing publication/rollback, gym rename/archive and invalid auto-update preserve correct public links/content; central Orb Gym site never becomes a private customer gym directory automatically. |
| AC51 | All role/module routes including Documents, coaching, publishing and finance are reachable within permission on desktop/tablet/mobile; exact footer is visible without obscuring bottom controls. |
| AC52 | Every preset resolves its token contract across all major components/states; theme changes preserve data/drafts and do not unexpectedly activate a brand. |
| AC53 | Full feed inventory, media replies, reporting/moderation and feedback resolution obey audience rules; additional social features are not claimed without scoped acceptance. |
| AC54 | File validation/private delivery, unavailable providers, duplicate background work, monitoring and rollback/restore are verified against agreed measurable targets before release. |

| ID | Delivery-plan verification outcome |
|---|---|
| AC55 | Initial Orb Gym delivery cards have unique contiguous numbers from 00, prerequisite-before-dependent order, parent/child rollups distinguished from blockers, stable platform IDs and matching file references; board ordering or its explicit indexed fallback is verified. |
