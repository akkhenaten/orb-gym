# Design and Token Delivery Contract

Review r1. Source: all five UI preset rules and responsive navigation. This is a specification requirement, not a supplied production token library.

## OG-REV-008 — Concrete design outputs

The builder's plan must identify the screens/components, selected variants, token definitions and mode-specific resolved values it will deliver. Use stable preset IDs: basic-01, flat-02, editorial-03, glass-04 and console-05. Soft Glass 04 is the same direction previously summarised as iOS-inspired Soft; it is not a sixth preset.

For each token record ID, type, semantic purpose, scope, source, status (source value/proposed/approved), value or reference, light/dark mapping, permitted company/gym override and validation constraint. Resolve every required token for every preset; do not treat sparse palette examples as complete themes. Define foundation → semantic → component aliases, fonts/fallbacks/assets, typography, spacing, size/density, radii, borders, elevation, motion, focus and all interactive states. The initial Basic source palette remains the visual reference; proposed dark mappings and secondary-preset values still need review.

Map component variants for navigation, calendar, tables, forms, feed/composer, tri-pane item cards, reception ID card, class/register, till, receipt preview, document composer, landing page and coach flip card. Verify loading/empty/error/disabled/focus/selected states and long content. Module-specific hard-coded styles require documented exceptions; appearance changes cannot alter permissions or state transitions.

Personal light/dark/system preference remains separate from company branding. Distinguish configurable style selection from explicit white-label activation. Record the preview/publish/rollback and permitted gym-override behaviour so theme publication cannot accidentally activate an unapproved logo. Provide an opaque fallback for glass and preserve the exact footer in all presets/modes.

Produce a responsive role/screen matrix: owner desktop/mobile, staff desktop/mobile, member mobile, vendor responsive, plus iPad/tablet including landscape. Content panes adapt independently of the mandated bottom navigation on tablets. Define accessible labels, reading/focus order, zoom/reflow, keyboard/touch, reduced motion and media viewer return behaviour. Font licensing/delivery and final reverse/icon logo files are design dependencies to record.

The five visual concept images and exact wireframes are not included in this pack and have not been inspected in this audit. Their style descriptions are included. OpenKBS must not claim concept-image fidelity or an approved Figma baseline from these text files.
