# Builder Generated Delivery Outputs

Generate the implementation-plan.md, requirements-coverage.csv, decision-log.md, card-index.md and verification-plan.md at project-root docs/delivery/, as specified in prompt 02. This directory in the baseline describes the output contract; it is not evidence that a plan or cards already exist.

The atomic coverage matrix must distinguish planned work, existing verified capability, a blocked decision, explicitly excluded/superseded scope and contextual information. Do not claim full coverage from section headings alone. Requirements may have multiple cards and acceptance scenarios; preserve those mappings.

Keep a dated revision history. After later authorised implementation, record evidence on cards and update coverage; do not retrospectively describe planned checks as executed.


Review r1 also requires platform-capability-matrix.md, access-matrix.md, screen-and-notification-matrix.md, design-token-map.md and report-catalogue.md at project-root docs/delivery/. Coverage includes both OG-SRC and OG-REV IDs, with source status and disposition. The source baseline's corrected working copy and history are intentionally distinct.

Revision r2: OG-REV-011 requires a single dependency-ordered sequence of delivery cards from 00, 01, 02 onward. Follow docs/board-card-contract.md for title format, parent/child handling, stable platform IDs, ordering checks and subsequent changes. Include sequence numbers alongside board IDs in all delivery mappings.
